% BMS settings
Safety.UVP_limit = 3000;            %[mV]   Undervoltage protection - UVP limit of a single cell 
Safety.OVP_limit = 4200;            %[mV]   Overvoltage protection - OVP limit of a single cell 
Safety.UTP_limit = 0;               %[C]    Undertemperature protection - UTP limit
Safety.OTP_limit = 45;              %[C]    Overtemperature protection - OTP limit
Safety.OCP_limit = -30;             %[A]    Overcurrent protection - OCP limit
Safety.OVP_Stack = 4200;            %[mV]   OVP of the battery stack (multiplied by #cells in the safety check)
Safety.UVP_Stack = 3000;            %[mV]   UVP of the battery (multiplied by #cells in the safety check)
Safety.TimeOut_limit = 1;           %[s]    time before going into error state when a safety check fails
Safety.ChargeDetectionCurrent = 0.1;%[A]    if the current is higher than this threshold, it results into a state transition to charge mode
Safety.ChargeDelay = 1;             %[s]    time delay before the transitioning to charge mode
Safety.Ncells = 6;                  %[-]    number of cells used. ALSO SET THE JUMPERS CORRECTLY ACCORDING TO THE SCHEMATIC
Safety.external_NTC = 0;            %[-]    whether or not to use the external NTC
Safety.Capacity = 5000;             %[mAh]  Capacity of the cells

% OCV SoC settings
% these values are an example of a LiPo (Lithium Nickel Manganese Cobalt Oxide (LiNiMnCoO2)) battery cell
%[%] State of charge percentage array used in lookup table
OCV.StateofCharge = [0,     1,     2,     3,     4,     5,     6,     7,     8,     9,    10,    11,    12,    13,    15,    17,    18,    20,    22,    24,    25,    27,    29,    31,    32,    34,    36,    38,    40,    41,    43,    45,    47,    49,    51,    52,    54,    56,    58,    60,    62,    64,    66,    68,    70,    72,    73,    75,    78,    80,    82,    84,    86,    88,    90,    92,    94,    96,    99,   100];
% [mV] State of charge cell voltage used in lookup table
OCV.Cellvoltage = [3313,        3417,        3503,        3568,        3605,        3642,        3666,        3675,        3680,        3683,        3686,        3688,        3692,        3698,        3710,        3718,        3727,        3734,        3740,        3745,        3751,        3758,        3765,        3771,        3778,        3783,        3787,        3792,        3796,        3802,        3807,        3813,        3819,        3826,        3833,        3841,        3850,        3859,        3869,        3881,        3895,        3912,        3930,        3945,        3959,        3972,        3984,        3997,        4011,        4028,        4047,        4065,        4079,        4095,        4113,        4131,        4149,        4168,        4187,        4200];

% Charge settings
Charge.maxCell_voltage = 4100;      %[mV]   stop charging if this voltage is reached
Charge.enable_balancing = 1;        %[-]    whether or not to enable balancing
Charge.balance_margin = 50;         %[mV]   stop balancing if within this margin
Charge.relaxation_time = 300;       %[s]    go to relaxation state after this time to ensure settled cells

% generic settings
Generic.PeripheralOutputTime = 1;   %[s] output rate of CAN, UART and display (should be a scalar of modelruntime). If modelruntime > param -> perihperaltime = modelruntime
Generic.ModelRuntime = 0.1;         %[s]    model runtime
Generic.BalanceTime = 0;            %[min]  balancing time in minutes; if 0 then 30s
Generic.RShunt = 500;               %[μΩ]   shunt resistance value in micro ohm