% Load general settings
BMS_settings;

% LiPo settings
Safety.UVP_limit = 3000;     %[mV]       UVP limit 
Safety.OVP_limit = 4200;     %[mV]       OVP limit 
Safety.UVP_Stack = 3000;      %[mV]        UVP of Stack
Safety.OVP_Stack = 4200;    %[mV]        OVP of Stack





