% Copyright (c) 2024, NXP
% SPDX-License-Identifier: BSD-3-Clause
% The BSD-3-Clause license can be found at https://spdx.org/licenses/BSD-3-Clause.html

% This script must be run before the model is built
% It is called automatically from the PreLoadFCN Callback, which can be found
% in the Model Properties.
% It creates a prompt where you need to choose for which celltype you want to
% build the model. Next, the correct Settings file is run, where all
% parameters are defined. These variables are
% then loaded into the Model Workspace, and they can be used anywhere in
% the model. This avoids so-called "magic constants" in the model. For
% example, if the UVP of the BMS changes, you need to change only one
% value in the settings file, instead of having to search for every block
% which uses the UVP of the BMS.
clearvars; close all; clc;

% Get model workspace
try
    mdlWks = get_param('rddrone_bms_app', 'ModelWorkspace');
catch
    fprintf("The rddrone_bms_app.slx Simulink model needs to be loaded to be able to parse the configs\n");
    return
end

% Possible BMS settings
celltypes = {'LiFe', 'LiPo'};

% Create prompt to choose cell type
[cell_idx, tf] = listdlg('ListString', celltypes, 'PromptString', 'Select cell type', ...
    'SelectionMode', 'single', 'InitialValue', 2);

if tf == 0
    fprintf('Abort: No cell type ID was selected\n')
    return
end

CELL_TYPE = celltypes{cell_idx};

fprintf('Selected %s\n', CELL_TYPE);

% Select correct data file
mdlWks.FileName = sprintf('%s_settings.m', CELL_TYPE);

% Reload variables in model workspace
mdlWks.reload()