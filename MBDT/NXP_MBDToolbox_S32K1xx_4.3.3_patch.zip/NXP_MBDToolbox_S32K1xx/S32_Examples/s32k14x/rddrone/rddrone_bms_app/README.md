# Installation
This example uses MATLAB2023b. Make sure to install the folowing toolboxes:
	- Simulink
	- Simulink Coder
	- MATLAB Coder
	- NXP_MBDToolbox_S32K1xx
	- Embedded Coder
	- Stateflow
    - Vehicle Networking Toolbox

Furthermore, the model makes use of NVM, however, to ensure the flash memory is empty
it is recommended to erase the chip before uploading the model (e.g. via JLink commander).
	
# Upload the model
- uploading/compiling the model goes via JTAG (Segger Jlink). To use this, JLINK commander needs to be installed.
- after the correct software is installed, the upload process should be as easy as pressing ctrl+b when the jlink programmer is connected and the BMS is powered (press button to enable power to MCU).

# Functionalities
The model currently consists of the following functionalities:
- reading in the BCC data
- storing/reading of non-volatile memory
- Simple statemachine, consisting of init, normal, charge and fault state
- error detection of the BMS
- outputting data over CAN, UART, display, LEDs
- controlling the gate drivers
- controlling balancing

# Model configurations
When opening the model, a menu pops up asking for the selection of a cell-type. This loads in a structure with pre-defined settings to be used in the simulink model. 	   
The model uses many configs, and in order to prevent hardcoding values in the model/duplicate values, a structure containing all important values/defines is introduced. 
The generic structure, defining all parameters (and explaining what they do) is introduced in Settings/BMS_settings.m. 
The LiFe and LiPo files use this generic structure and make it more use-case specific, by changing/altering some of these values. 
This structure can be easily expanded for testing.

# Model structure
This model consists of 4 main parts. The first part is the setup of the model, which sets up all the peripherals used and the chip itself. 
The second part consists of all incoming data, which in this case is data incoming from the BCC and storing non-volatile memory. 
The third part is the statemachine, where firstly error detection is performed (consisting of OVP/UVP/OTP/UTP/OCP/Communication loss). 
If there is an error, a counter is increment, else it is decremented. If this counter exceeds a certain threshold, the BMS goes into fault state. 

The statemachine itself is relatively straightforward, namely:

It starts in an initialisation state, where it is checked whether the safety check is passed or not (such that if it isn't passed on start-up, the gate drivers won't close).

The second state is the normal/operational mode, where the gate is closed (power to the output is enabled) and the LED turns green.

The third state is the charge state, which includes a basic charging algorithm. 
This charging state is entered if the current goes below a certain (negative) value for a certain amount of time specified in the configs. 
When this changing state is reached, the LED will turn blue and the charging state subsystem is enabled.
In the charging state subsystem, it is checked whether the maximum cell voltage exceeds a certain threshold defined in the configs, if
this is the case, there is a relaxation time in which the algorithm will wait for the cells to settle. Afterward, balancing is performed;
all cells get balanced, until they reach the voltage of the lowest cell (plus a small margin). If balancing is finished, the charging state
is done.

If in any of these states a BMS error is set, it will go into fault state, which is latching and opens the gate drivers (power turns off). 
This will also turn the LED red. 

The statemachine outputs the LED state and the state for the gate driver. 

# Communication
CAN: the CAN bus is enabled with a bitrate of 1000 Kbit/s. For CAN0, you can use J3 or J20. 
Attach a CAN device that is able to read it and make sure the bus is ended with a termination resistor. There is no termination
present on the BMS by default.
The data on the CAN bus are two messages given by:
CAN ID: 0x320, DLC 8, first 4 bytes the total voltage, 4 bytes the NVM value
CAN ID: 0x321, DLC 4, 4 bytes of average current

UART: The UART uses 115.200 BAUD and can be connected to J19 (via DCD-LZ or your own cable connected to an FTDI-3V3 cable).
On the UART the following data can be found: Which error (e.g. OVP, OTP), the state of the statemachine, the pack voltage,
the average current, the SoC and the user command which can be used to reset the BMS ("bms reset") in human readable chars.

Display: The SSD1306 0.91" display can be attached to J23 to see the error, the average current and the stack voltage.

LED: The LED is used for status indication. These are the colors with its meaning:
Init mode: 		LED off
normal mode: 	LED green
charge mode: 	LED blue
fault mode: 	LED red


